"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type React from "react"

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { AlertCircle, BookOpen, History, GraduationCap, ArrowRight, RefreshCw } from "lucide-react"
import { useState, useEffect } from "react"

export default function CalculusPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-8 px-4 md:px-8">
        <div className="container mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Cálculo Diferencial</h1>
          <p className="text-xl md:text-2xl">Límites y Funciones</p>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4 md:px-8">
        <Tabs defaultValue="funciones" className="w-full">
          <TabsList className="grid grid-cols-2 md:grid-cols-4 mb-8">
            <TabsTrigger value="funciones" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              <span>Funciones</span>
            </TabsTrigger>
            <TabsTrigger value="limites" className="flex items-center gap-2">
              <ArrowRight className="h-4 w-4" />
              <span>Límites</span>
            </TabsTrigger>
            <TabsTrigger value="historia" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              <span>Historia</span>
            </TabsTrigger>
            <TabsTrigger value="test" className="flex items-center gap-2">
              <GraduationCap className="h-4 w-4" />
              <span>Test</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="funciones">
            <FuncionesContent />
          </TabsContent>

          <TabsContent value="limites">
            <LimitesContent />
          </TabsContent>

          <TabsContent value="historia">
            <HistoriaContent />
          </TabsContent>

          <TabsContent value="test">
            <TestContent />
          </TabsContent>
        </Tabs>
      </main>

      <footer className="bg-slate-800 text-white py-6 px-4 md:px-8">
        <div className="container mx-auto text-center">
          <p>© {new Date().getFullYear()} Cálculo Diferencial - Todos los derechos reservados</p>
        </div>
      </footer>
    </div>
  )
}

// Componentes para expresiones matemáticas
const Fraction = ({ numerator, denominator }: { numerator: React.ReactNode; denominator: React.ReactNode }) => (
  <div className="inline-flex flex-col items-center mx-1">
    <div className="text-center px-1">{numerator}</div>
    <div className="border-t border-black w-full"></div>
    <div className="text-center px-1">{denominator}</div>
  </div>
)

const Limit = ({
  variable,
  approach,
  expression,
}: { variable: string; approach: React.ReactNode; expression: React.ReactNode }) => (
  <div className="inline-flex items-center">
    <div className="mr-1">lim</div>
    <div className="text-xs flex flex-col items-center">
      <div>
        {variable}→{approach}
      </div>
    </div>
    <div className="ml-1">{expression}</div>
  </div>
)

const Sqrt = ({ expression }: { expression: React.ReactNode }) => (
  <div className="inline-flex items-center">
    <div className="relative">
      <span className="text-lg">√</span>
      <div className="inline-block border-t border-black ml-2">{expression}</div>
    </div>
  </div>
)

function FuncionesContent() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-4">Funciones en Cálculo Diferencial</h2>

      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="definicion">
          <AccordionTrigger>Definición de Función</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>
                Una <strong>función</strong> es una relación entre un conjunto de entradas (dominio) y un conjunto de
                salidas (rango), donde cada entrada se relaciona exactamente con una salida.
              </p>

              <p>
                Formalmente, una función f de un conjunto A a un conjunto B es una regla que asigna a cada elemento x en
                A exactamente un elemento y en B. Escribimos:
              </p>

              <div className="bg-slate-100 p-4 rounded-md my-4">
                <p className="text-center">f: A → B</p>
                <p className="text-center">y = f(x)</p>
              </div>

              <p>Donde:</p>
              <ul className="list-disc pl-6">
                <li>x es la variable independiente (entrada)</li>
                <li>y es la variable dependiente (salida)</li>
                <li>A es el dominio de la función</li>
                <li>B es el codominio de la función</li>
              </ul>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="dominio-rango">
          <AccordionTrigger>Dominio y Rango</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>
                <strong>Dominio:</strong> Es el conjunto de todos los valores posibles de la variable independiente (x)
                para los cuales la función está definida.
              </p>

              <p>
                <strong>Rango:</strong> Es el conjunto de todos los valores posibles que puede tomar la variable
                dependiente (y) como resultado de aplicar la función.
              </p>

              <div className="bg-slate-100 p-4 rounded-md my-4">
                <p className="font-semibold">Ejemplo:</p>
                <p>
                  Para la función f(x) = x², el dominio es ℝ (todos los números reales), pero el rango es [0, ∞) (todos
                  los números reales no negativos).
                </p>
              </div>

              <p>
                Para determinar el dominio, debemos identificar los valores de x para los cuales la función está
                definida. Algunas restricciones comunes son:
              </p>
              <ul className="list-disc pl-6">
                <li>No podemos dividir por cero</li>
                <li>No podemos tomar la raíz cuadrada de un número negativo (en los números reales)</li>
                <li>No podemos tomar el logaritmo de un número negativo o cero</li>
              </ul>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="tipos-funciones">
          <AccordionTrigger>Tipos de Funciones</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>Existen diversos tipos de funciones con características específicas:</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Funciones Polinómicas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>Son de la forma f(x) = a₀ + a₁x + a₂x² + ... + aₙxⁿ</p>
                    <p className="mt-2">Ejemplos:</p>
                    <ul className="list-disc pl-6">
                      <li>f(x) = 3x + 2</li>
                      <li>f(x) = x² - 4x + 7</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Funciones Racionales</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>Son cocientes de polinomios: f(x) = P(x)/Q(x)</p>
                    <p className="mt-2">Ejemplos:</p>
                    <ul className="list-disc pl-6">
                      <li>f(x) = 1/x</li>
                      <li>f(x) = (x² + 1)/(x - 3)</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Funciones Exponenciales</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>
                      Son de la forma f(x) = aˣ, donde a {">"} 0, a {"≠"} 1
                    </p>
                    <p className="mt-2">Ejemplos:</p>
                    <ul className="list-disc pl-6">
                      <li>f(x) = 2ˣ</li>
                      <li>f(x) = eˣ</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Funciones Logarítmicas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>
                      Son de la forma f(x) = log_a(x), donde a {">"} 0, a {"≠"} 1
                    </p>
                    <p className="mt-2">Ejemplos:</p>
                    <ul className="list-disc pl-6">
                      <li>f(x) = log₁₀(x)</li>
                      <li>f(x) = ln(x)</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Funciones Trigonométricas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>Incluyen seno, coseno, tangente, etc.</p>
                    <p className="mt-2">Ejemplos:</p>
                    <ul className="list-disc pl-6">
                      <li>f(x) = sin(x)</li>
                      <li>f(x) = cos(2x)</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Funciones a Trozos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>Definidas por diferentes expresiones en diferentes partes del dominio</p>
                    <p className="mt-2">Ejemplo:</p>
                    <p>f(x) = {"{x² si x ≥ 0, -x si x < 0}"}</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="propiedades">
          <AccordionTrigger>Propiedades de las Funciones</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>Las funciones pueden tener diversas propiedades que nos ayudan a entender su comportamiento:</p>

              <div className="space-y-6">
                <div>
                  <h3 className="font-bold text-lg">Inyectividad (One-to-One)</h3>
                  <p>Una función es inyectiva si elementos diferentes del dominio tienen imágenes diferentes.</p>
                  <p className="italic">Formalmente: f(x₁) = f(x₂) implica x₁ = x₂</p>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Sobreyectividad (Onto)</h3>
                  <p>
                    Una función es sobreyectiva si todo elemento del codominio es imagen de al menos un elemento del
                    dominio.
                  </p>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Biyectividad</h3>
                  <p>Una función es biyectiva si es tanto inyectiva como sobreyectiva.</p>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Paridad</h3>
                  <p>
                    <strong>Función par:</strong> f(-x) = f(x) para todo x en el dominio. Son simétricas respecto al eje
                    Y.
                  </p>
                  <p>
                    <strong>Función impar:</strong> f(-x) = -f(x) para todo x en el dominio. Son simétricas respecto al
                    origen.
                  </p>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Periodicidad</h3>
                  <p>
                    Una función f es periódica si existe un número p {">"} 0 tal que f(x + p) = f(x) para todo x en el
                    dominio.
                  </p>
                  <p>El menor valor positivo de p es el período de la función.</p>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Monotonía</h3>
                  <p>
                    <strong>Creciente:</strong> Si x₁ {"<"} x₂ implica f(x₁) {"≤"} f(x₂)
                  </p>
                  <p>
                    <strong>Estrictamente creciente:</strong> Si x₁ {"<"} x₂ implica f(x₁) {"<"} f(x₂)
                  </p>
                  <p>
                    <strong>Decreciente:</strong> Si x₁ {"<"} x₂ implica f(x₁) {"≥"} f(x₂)
                  </p>
                  <p>
                    <strong>Estrictamente decreciente:</strong> Si x₁ {"<"} x₂ implica f(x₁) {">"} f(x₂)
                  </p>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="operaciones">
          <AccordionTrigger>Operaciones con Funciones</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>Dadas dos funciones f y g, podemos definir nuevas funciones mediante operaciones:</p>

              <div className="bg-slate-100 p-4 rounded-md">
                <ul className="space-y-2">
                  <li>
                    <strong>Suma:</strong> (f + g)(x) = f(x) + g(x)
                  </li>
                  <li>
                    <strong>Resta:</strong> (f - g)(x) = f(x) - g(x)
                  </li>
                  <li>
                    <strong>Producto:</strong> (f · g)(x) = f(x) · g(x)
                  </li>
                  <li>
                    <strong>Cociente:</strong> (f/g)(x) = f(x)/g(x), donde g(x) {"≠"} 0
                  </li>
                  <li>
                    <strong>Composición:</strong> (f ∘ g)(x) = f(g(x))
                  </li>
                </ul>
              </div>

              <div className="mt-4">
                <h3 className="font-bold text-lg">Ejemplo de Composición:</h3>
                <p>Si f(x) = x² y g(x) = x + 1, entonces:</p>
                <ul className="list-disc pl-6">
                  <li>(f ∘ g)(x) = f(g(x)) = f(x + 1) = (x + 1)²</li>
                  <li>(g ∘ f)(x) = g(f(x)) = g(x²) = x² + 1</li>
                </ul>
                <p className="mt-2">Observe que en general (f ∘ g)(x) ≠ (g ∘ f)(x)</p>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="continuidad">
          <AccordionTrigger>Continuidad de Funciones</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>Una función f es continua en un punto c si se cumplen las siguientes condiciones:</p>

              <ol className="list-decimal pl-6 space-y-2">
                <li>f(c) está definida (c está en el dominio de f)</li>
                <li>Existe el límite de f cuando x tiende a c</li>
                <li>
                  El límite coincide con el valor de la función: lim<sub>x→c</sub> f(x) = f(c)
                </li>
              </ol>

              <p>Una función es continua en un intervalo si es continua en cada punto del intervalo.</p>

              <div className="bg-slate-100 p-4 rounded-md my-4">
                <p className="font-semibold">Tipos de discontinuidades:</p>
                <ul className="list-disc pl-6">
                  <li>
                    <strong>Discontinuidad evitable:</strong> Existe el límite pero no coincide con f(c) o f(c) no está
                    definida
                  </li>
                  <li>
                    <strong>Discontinuidad de salto:</strong> Existen los límites laterales pero son diferentes
                  </li>
                  <li>
                    <strong>Discontinuidad infinita:</strong> El límite es infinito
                  </li>
                  <li>
                    <strong>Discontinuidad oscilante:</strong> El límite no existe y no es infinito
                  </li>
                </ul>
              </div>

              <p>Las funciones continuas tienen propiedades importantes:</p>
              <ul className="list-disc pl-6">
                <li>
                  <strong>Teorema del valor intermedio:</strong> Si f es continua en [a,b] y k es un valor entre f(a) y
                  f(b), entonces existe c en [a,b] tal que f(c) = k
                </li>
                <li>
                  <strong>Teorema del valor extremo:</strong> Si f es continua en un intervalo cerrado [a,b], entonces f
                  alcanza un valor máximo y un valor mínimo en ese intervalo
                </li>
              </ul>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  )
}

function LimitesContent() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-4">Límites en Cálculo Diferencial</h2>

      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="concepto">
          <AccordionTrigger>Concepto de Límite</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>
                El <strong>límite</strong> de una función describe el comportamiento de la función cuando la variable
                independiente se aproxima a un valor específico.
              </p>

              <p>
                Intuitivamente, decir que el límite de f(x) cuando x tiende a c es L, significa que podemos hacer que
                f(x) esté tan cerca de L como queramos, tomando x suficientemente cerca de c (pero distinto de c).
              </p>

              <div className="bg-slate-100 p-4 rounded-md my-4">
                <p className="text-center">
                  lim<sub>x→c</sub> f(x) = L
                </p>
              </div>

              <p>
                <strong>Definición formal (ε-δ):</strong> El límite de f(x) cuando x tiende a c es L si para todo ε{" "}
                {">"} 0, existe δ {">"} 0 tal que:
              </p>
              <div className="bg-slate-100 p-3 rounded-md my-3 text-center">
                <p>
                  Si 0 {"<"} |x - c| {"<"} δ, entonces |f(x) - L| {"<"} ε
                </p>
              </div>

              <p>Es importante notar que:</p>
              <ul className="list-disc pl-6">
                <li>El límite no depende del valor de f(c), sino del comportamiento de f cerca de c</li>
                <li>f(c) puede no estar definida, pero el límite puede existir</li>
                <li>Si f(c) está definida, no necesariamente coincide con el límite</li>
              </ul>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="limites-laterales">
          <AccordionTrigger>Límites Laterales</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>
                Los <strong>límites laterales</strong> describen el comportamiento de una función cuando la variable
                independiente se aproxima a un valor desde la izquierda o desde la derecha.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-100 p-4 rounded-md">
                  <p className="font-semibold">Límite por la izquierda:</p>
                  <p className="text-center">
                    lim<sub>x→c⁻</sub> f(x) = L₁
                  </p>
                  <p className="mt-2">
                    Describe el comportamiento de f(x) cuando x se aproxima a c con valores menores que c.
                  </p>
                </div>

                <div className="bg-slate-100 p-4 rounded-md">
                  <p className="font-semibold">Límite por la derecha:</p>
                  <p className="text-center">
                    lim<sub>x→c⁺</sub> f(x) = L₂
                  </p>
                  <p className="mt-2">
                    Describe el comportamiento de f(x) cuando x se aproxima a c con valores mayores que c.
                  </p>
                </div>
              </div>

              <p className="font-semibold mt-4">Relación con el límite bilateral:</p>
              <p>
                El límite de f(x) cuando x tiende a c existe si y solo si existen ambos límites laterales y son iguales:
              </p>
              <div className="bg-slate-100 p-4 rounded-md my-2">
                <p className="text-center">
                  lim<sub>x→c</sub> f(x) = L ⟺ lim<sub>x→c⁻</sub> f(x) = lim<sub>x→c⁺</sub> f(x) = L
                </p>
              </div>

              <div className="mt-4">
                <p className="font-semibold">Ejemplo:</p>
                <p>
                  Para la función f(x) = |x|/x (que es igual a 1 si x {">"} 0 y -1 si x {"<"} 0):
                </p>
                <ul className="list-disc pl-6">
                  <li>
                    lim<sub>x→0⁻</sub> f(x) = -1
                  </li>
                  <li>
                    lim<sub>x→0⁺</sub> f(x) = 1
                  </li>
                </ul>
                <p>
                  Como los límites laterales son diferentes, lim<sub>x→0</sub> f(x) no existe.
                </p>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="propiedades-limites">
          <AccordionTrigger>Propiedades de los Límites</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>Los límites cumplen varias propiedades algebraicas que facilitan su cálculo:</p>

              <div className="bg-slate-100 p-4 rounded-md">
                <p className="font-semibold mb-2">
                  Supongamos que lim<sub>x→c</sub> f(x) = L y lim<sub>x→c</sub> g(x) = M:
                </p>
                <ul className="space-y-3 mt-2">
                  <li>
                    <strong>Límite de una constante:</strong>
                    <div className="bg-white p-2 rounded-md my-1 inline-block ml-2">
                      lim<sub>x→c</sub> k = k
                    </div>
                  </li>
                  <li>
                    <strong>Límite de la identidad:</strong>
                    <div className="bg-white p-2 rounded-md my-1 inline-block ml-2">
                      lim<sub>x→c</sub> x = c
                    </div>
                  </li>
                  <li>
                    <strong>Límite de una suma:</strong>
                    <div className="bg-white p-2 rounded-md my-1 inline-block ml-2">
                      lim<sub>x→c</sub> [f(x) + g(x)] = L + M
                    </div>
                  </li>
                  <li>
                    <strong>Límite de una diferencia:</strong>
                    <div className="bg-white p-2 rounded-md my-1 inline-block ml-2">
                      lim<sub>x→c</sub> [f(x) - g(x)] = L - M
                    </div>
                  </li>
                  <li>
                    <strong>Límite de un producto:</strong>
                    <div className="bg-white p-2 rounded-md my-1 inline-block ml-2">
                      lim<sub>x→c</sub> [f(x) · g(x)] = L · M
                    </div>
                  </li>
                  <li>
                    <strong>Límite de un cociente:</strong>
                    <div className="bg-white p-2 rounded-md my-1 inline-block ml-2">
                      lim<sub>x→c</sub> [f(x)/g(x)] = L/M, si M {"≠"} 0
                    </div>
                  </li>
                  <li>
                    <strong>Límite de una potencia:</strong>
                    <div className="bg-white p-2 rounded-md my-1 inline-block ml-2">
                      lim<sub>x→c</sub> [f(x)]ⁿ = Lⁿ
                    </div>
                  </li>
                  <li>
                    <strong>Límite de una raíz:</strong>
                    <div className="bg-white p-2 rounded-md my-1 inline-block ml-2">
                      lim<sub>x→c</sub> ⁿ√f(x) = ⁿ√L, si L {">"} 0 para n par
                    </div>
                  </li>
                </ul>
              </div>

              <p className="font-semibold mt-4">Teorema del Sándwich (o del Apretón):</p>
              <p>
                Si g(x) {"≤"} f(x) {"≤"} h(x) para todo x cercano a c (excepto posiblemente en c) y lim<sub>x→c</sub>{" "}
                g(x) = lim<sub>x→c</sub> h(x) = L, entonces lim<sub>x→c</sub> f(x) = L.
              </p>

              <div className="mt-4">
                <p className="font-semibold">Ejemplo del Teorema del Sándwich:</p>
                <p>
                  Para calcular lim<sub>x→0</sub> x²·sin(1/x):
                </p>
                <p>
                  Sabemos que -1 {"≤"} sin(1/x) {"≤"} 1 para todo x ≠ 0
                </p>
                <p>
                  Por lo tanto: -x² {"≤"} x²·sin(1/x) {"≤"} x²
                </p>
                <p>
                  Como lim<sub>x→0</sub> (-x²) = lim<sub>x→0</sub> x² = 0, por el teorema del sándwich:
                </p>
                <p>
                  lim<sub>x→0</sub> x²·sin(1/x) = 0
                </p>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="limites-infinitos">
          <AccordionTrigger>Límites Infinitos y al Infinito</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-100 p-4 rounded-md">
                  <p className="font-semibold">Límites infinitos:</p>
                  <p>Cuando el valor de la función crece o decrece sin cota cuando x se acerca a c:</p>
                  <ul className="mt-2">
                    <li>
                      lim<sub>x→c</sub> f(x) = ∞ (la función tiende a infinito)
                    </li>
                    <li>
                      lim<sub>x→c</sub> f(x) = -∞ (la función tiende a menos infinito)
                    </li>
                  </ul>
                </div>

                <div className="bg-slate-100 p-4 rounded-md">
                  <p className="font-semibold">Límites al infinito:</p>
                  <p>Cuando estudiamos el comportamiento de la función para valores de x muy grandes:</p>
                  <ul className="mt-2">
                    <li>
                      lim<sub>x→∞</sub> f(x) = L (límite cuando x tiende a infinito)
                    </li>
                    <li>
                      lim<sub>x→-∞</sub> f(x) = L (límite cuando x tiende a menos infinito)
                    </li>
                  </ul>
                </div>
              </div>

              <p className="font-semibold mt-4">Asíntotas verticales:</p>
              <p>
                Si lim<sub>x→c</sub> f(x) = ±∞, entonces la recta x = c es una asíntota vertical de la gráfica de f.
              </p>

              <p className="font-semibold mt-4">Asíntotas horizontales:</p>
              <p>
                Si lim<sub>x→±∞</sub> f(x) = L, entonces la recta y = L es una asíntota horizontal de la gráfica de f.
              </p>

              <div className="mt-4">
                <p className="font-semibold">Límites importantes:</p>
                <ul className="list-disc pl-6">
                  <li>
                    lim<sub>x→∞</sub> (1/x) = 0
                  </li>
                  <li>
                    lim<sub>x→∞</sub> (x^n/x^m) = 0 si n {"<"} m
                  </li>
                  <li>
                    lim<sub>x→∞</sub> (x^n/x^m) = ∞ si n {">"} m
                  </li>
                  <li>
                    lim<sub>x→∞</sub> (x^n/x^m) = 1 si n {"="} m
                  </li>
                  <li>
                    lim<sub>x→∞</sub> (1 + 1/x)^x = e
                  </li>
                </ul>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="indeterminaciones">
          <AccordionTrigger>Formas Indeterminadas</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>
                Las <strong>formas indeterminadas</strong> son expresiones límite que no pueden evaluarse directamente
                usando las propiedades algebraicas de los límites.
              </p>

              <div className="bg-slate-100 p-4 rounded-md">
                <p className="font-semibold">Principales formas indeterminadas:</p>
                <ul className="space-y-2 mt-2">
                  <li>
                    <strong>0/0:</strong> Cociente donde numerador y denominador tienden a cero
                  </li>
                  <li>
                    <strong>∞/∞:</strong> Cociente donde numerador y denominador tienden a infinito
                  </li>
                  <li>
                    <strong>0·∞:</strong> Producto donde un factor tiende a cero y otro a infinito
                  </li>
                  <li>
                    <strong>∞-∞:</strong> Diferencia de dos términos que tienden a infinito
                  </li>
                  <li>
                    <strong>0⁰:</strong> Potencia donde base e índice tienden a cero
                  </li>
                  <li>
                    <strong>∞⁰:</strong> Potencia donde base tiende a infinito e índice tiende a cero
                  </li>
                  <li>
                    <strong>1^∞:</strong> Potencia donde base tiende a uno e índice tiende a infinito
                  </li>
                </ul>
              </div>

              <p className="font-semibold mt-4">Técnicas para resolver indeterminaciones:</p>

              <ol className="list-decimal pl-6 space-y-2">
                <li>
                  <strong>Factorización:</strong> Útil para formas 0/0, factorizando y simplificando
                </li>
                <li>
                  <strong>Racionalización:</strong> Útil para algunas formas 0/0 con raíces
                </li>
                <li>
                  <strong>Regla de L'Hôpital:</strong> Si lim<sub>x→c</sub> f(x)/g(x) es de la forma 0/0 o ∞/∞,
                  entonces:
                  <div className="bg-slate-100 p-3 rounded-md my-3 text-center">
                    <p className="text-lg">
                      lim<sub>x→c</sub> <span className="inline-block border-b border-black mx-1 px-2">f(x)</span>
                      <span className="inline-block mx-1">g(x)</span> = lim<sub>x→c</sub>{" "}
                      <span className="inline-block border-b border-black mx-1 px-2">f'(x)</span>
                      <span className="inline-block mx-1">g'(x)</span>
                    </p>
                  </div>
                  siempre que el límite de la derecha exista o sea ±∞
                </li>
                <li>
                  <strong>Cambio de variable:</strong> Especialmente útil en límites al infinito
                </li>
                <li>
                  <strong>Uso de equivalentes:</strong> Sustituir funciones por otras equivalentes cuando x→c
                </li>
              </ol>

              <div className="mt-4">
                <p className="font-semibold">Ejemplo:</p>
                <p>
                  Calcular lim<sub>x→0</sub> (sin x)/x
                </p>
                <p>
                  Esta es una indeterminación del tipo 0/0, ya que lim<sub>x→0</sub> sin x = 0 y lim<sub>x→0</sub> x = 0
                </p>
                <p>
                  Se puede demostrar que lim<sub>x→0</sub> (sin x)/x = 1
                </p>
                <p>
                  Este es un límite fundamental en cálculo y se usa para demostrar que la derivada de sin x es cos x.
                </p>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="aplicaciones">
          <AccordionTrigger>Aplicaciones de los Límites</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>Los límites tienen numerosas aplicaciones en matemáticas y otras disciplinas:</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Definición de Derivada</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>La derivada de una función f en un punto x se define como:</p>
                    <div className="bg-slate-100 p-3 rounded-md my-3 text-center">
                      <p className="text-lg">
                        f'(x) = lim<sub>h→0</sub>{" "}
                        <span className="inline-block border-b border-black mx-1 px-2">f(x+h) - f(x)</span>
                        <span className="inline-block mx-1">h</span>
                      </p>
                    </div>
                    <p>Este límite representa la tasa de cambio instantánea de la función.</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Continuidad</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>Una función f es continua en x = c si:</p>
                    <div className="bg-slate-100 p-2 rounded-md my-2">
                      <p className="text-center">
                        lim<sub>x→c</sub> f(x) = f(c)
                      </p>
                    </div>
                    <p>Los límites nos permiten estudiar y clasificar las discontinuidades.</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Asíntotas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>
                      Los límites nos permiten encontrar asíntotas verticales, horizontales y oblicuas de funciones.
                    </p>
                    <p>Por ejemplo, para una asíntota oblicua y = mx + b:</p>
                    <ul className="list-disc pl-6">
                      <li>
                        m = lim<sub>x→∞</sub> f(x)/x
                      </li>
                      <li>
                        b = lim<sub>x→∞</sub> [f(x) - mx]
                      </li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Sumas Infinitas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>El límite de las sumas parciales define la suma de una serie infinita:</p>
                    <div className="bg-slate-100 p-2 rounded-md my-2">
                      <p className="text-center">
                        ∑<sub>n=1</sub>
                        <sup>∞</sup> aₙ = lim<sub>m→∞</sub> ∑<sub>n=1</sub>
                        <sup>m</sup> aₙ
                      </p>
                    </div>
                    <p>Esto es fundamental en el análisis de series y en el cálculo integral.</p>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-4">
                <p className="font-semibold">Aplicaciones en física:</p>
                <ul className="list-disc pl-6">
                  <li>
                    <strong>Velocidad instantánea:</strong> lim<sub>Δt→0</sub> Δx/Δt
                  </li>
                  <li>
                    <strong>Aceleración instantánea:</strong> lim<sub>Δt→0</sub> Δv/Δt
                  </li>
                  <li>
                    <strong>Densidad de un material en un punto:</strong> lim<sub>ΔV→0</sub> Δm/ΔV
                  </li>
                </ul>
              </div>

              <div className="mt-4">
                <p className="font-semibold">Aplicaciones en economía:</p>
                <ul className="list-disc pl-6">
                  <li>
                    <strong>Costo marginal:</strong> lim<sub>Δx→0</sub> ΔC/Δx (tasa de cambio del costo respecto a la
                    producción)
                  </li>
                  <li>
                    <strong>Ingreso marginal:</strong> lim<sub>Δx→0</sub> ΔR/Δx (tasa de cambio del ingreso respecto a
                    la producción)
                  </li>
                  <li>
                    <strong>Elasticidad de la demanda:</strong> lim<sub>Δp→0</sub> (Δq/q)/(Δp/p)
                  </li>
                </ul>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  )
}

function HistoriaContent() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-4">Evolución Histórica de Funciones y Límites</h2>

      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="antiguedad">
          <AccordionTrigger>Antigüedad y Edad Media</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>
                Aunque los conceptos formales de función y límite son relativamente recientes, sus ideas subyacentes
                tienen raíces antiguas:
              </p>

              <div className="space-y-4">
                <div>
                  <h3 className="font-bold text-lg">Matemáticas griegas (500 a.C. - 300 d.C.)</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>Eudoxo de Cnido (408-355 a.C.):</strong> Desarrolló el "método de exhaución", un precursor
                      del concepto de límite, para calcular áreas y volúmenes
                    </li>
                    <li>
                      <strong>Arquímedes (287-212 a.C.):</strong> Perfeccionó el método de exhaución y lo aplicó para
                      calcular el área del círculo y el volumen de la esfera
                    </li>
                    <li>
                      <strong>Zenón de Elea (490-430 a.C.):</strong> Sus famosas paradojas (como la de Aquiles y la
                      tortuga) planteaban cuestiones sobre el infinito y la continuidad
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Matemáticas indias y árabes (500-1500 d.C.)</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>Brahmagupta (598-668):</strong> Trabajó con reglas algebraicas que implícitamente usaban
                      relaciones funcionales
                    </li>
                    <li>
                      <strong>Al-Khwarizmi (780-850):</strong> Sus trabajos en álgebra establecieron métodos para
                      resolver ecuaciones que pueden verse como funciones
                    </li>
                    <li>
                      <strong>Bhaskara II (1114-1185):</strong> Estudió el concepto de "instantaneidad" en el
                      movimiento, relacionado con la idea de límite
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Europa medieval (1200-1500)</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>Nicole Oresme (1320-1382):</strong> Utilizó representaciones gráficas para mostrar
                      relaciones entre cantidades, anticipando la idea de función
                    </li>
                    <li>
                      <strong>Oxford Calculators:</strong> Grupo de matemáticos que estudiaron el movimiento y
                      desarrollaron el "teorema de la velocidad media", relacionado con el cálculo
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="siglos-xvii-xviii">
          <AccordionTrigger>Siglos XVII y XVIII: Nacimiento del Cálculo</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>
                Los siglos XVII y XVIII fueron cruciales para el desarrollo formal de los conceptos de función y límite:
              </p>

              <div className="space-y-4">
                <div>
                  <h3 className="font-bold text-lg">Precursores del cálculo</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>René Descartes (1596-1650):</strong> Su geometría analítica estableció la conexión entre
                      álgebra y geometría, fundamental para el concepto de función
                    </li>
                    <li>
                      <strong>Pierre de Fermat (1607-1665):</strong> Desarrolló métodos para encontrar máximos y
                      mínimos, y tangentes a curvas
                    </li>
                    <li>
                      <strong>John Wallis (1616-1703):</strong> Trabajó con series infinitas y el concepto de límite en
                      su "Arithmetica Infinitorum"
                    </li>
                    <li>
                      <strong>Isaac Barrow (1630-1677):</strong> Maestro de Newton, desarrolló un enfoque geométrico
                      para problemas de tangentes y áreas
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Fundadores del cálculo</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>Isaac Newton (1642-1727):</strong> Desarrolló el "método de fluxiones" (su versión del
                      cálculo) basado en cantidades que fluyen continuamente. Introdujo el concepto de "fluxión"
                      (derivada) como la tasa de cambio de una "fluente" (función)
                    </li>
                    <li>
                      <strong>Gottfried Wilhelm Leibniz (1646-1716):</strong> Desarrolló independientemente el cálculo
                      con una notación más clara y sistemática que perdura hasta hoy. Introdujo el término "función" en
                      1673 y desarrolló el cálculo diferencial e integral
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Desarrollo del concepto de función</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>Johann Bernoulli (1667-1748):</strong> Definió una función como "una cantidad formada de
                      alguna manera a partir de variables y constantes"
                    </li>
                    <li>
                      <strong>Leonhard Euler (1707-1783):</strong> Introdujo la notación f(x) y amplió el concepto de
                      función para incluir expresiones analíticas. Su obra "Introductio in Analysin Infinitorum" (1748)
                      fue fundamental para el desarrollo del análisis matemático
                    </li>
                    <li>
                      <strong>Joseph-Louis Lagrange (1736-1813):</strong> Intentó fundamentar el cálculo en series de
                      Taylor, evitando el uso de límites e infinitesimales
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="siglo-xix">
          <AccordionTrigger>Siglo XIX: Rigorización del Cálculo</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>El siglo XIX fue testigo de la formalización rigurosa de los conceptos de función y límite:</p>

              <div className="space-y-4">
                <div>
                  <h3 className="font-bold text-lg">Rigorización del concepto de límite</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>Augustin-Louis Cauchy (1789-1857):</strong> En su obra "Cours d'Analyse" (1821),
                      proporcionó la primera definición rigurosa de límite, similar a la moderna definición ε-δ. También
                      definió la continuidad en términos de límites
                    </li>
                    <li>
                      <strong>Bernard Bolzano (1781-1848):</strong> Trabajó independientemente en una definición
                      rigurosa de límite y demostró importantes teoremas sobre funciones continuas
                    </li>
                    <li>
                      <strong>Karl Weierstrass (1815-1897):</strong> Formalizó la definición ε-δ de límite que usamos
                      hoy y construyó ejemplos de funciones continuas que no son diferenciables en ningún punto
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Evolución del concepto de función</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>Jean-Baptiste Joseph Fourier (1768-1830):</strong> Su trabajo sobre la conducción del
                      calor llevó a las series de Fourier, ampliando significativamente el concepto de función
                    </li>
                    <li>
                      <strong>Peter Gustav Lejeune Dirichlet (1805-1859):</strong> Dio la definición moderna de función
                      como una correspondencia arbitraria entre conjuntos. Introdujo la función de Dirichlet (1 para
                      racionales, 0 para irracionales), un ejemplo importante de función patológica
                    </li>
                    <li>
                      <strong>Bernhard Riemann (1826-1866):</strong> Desarrolló la integral de Riemann y estudió
                      funciones con comportamientos complejos, ampliando aún más el concepto de función
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Teoría de conjuntos y fundamentación</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>Georg Cantor (1845-1918):</strong> Su teoría de conjuntos proporcionó un marco para
                      definir funciones como relaciones entre conjuntos
                    </li>
                    <li>
                      <strong>Richard Dedekind (1831-1916):</strong> Sus "cortaduras" proporcionaron una construcción
                      rigurosa de los números reales, esencial para el análisis
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="siglo-xx">
          <AccordionTrigger>Siglos XX y XXI: Generalización y Aplicaciones</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>
                En los siglos XX y XXI, los conceptos de función y límite se han generalizado y aplicado en numerosos
                campos:
              </p>

              <div className="space-y-4">
                <div>
                  <h3 className="font-bold text-lg">Generalización de los conceptos</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>Maurice René Fréchet (1878-1973):</strong> Generalizó el concepto de límite a espacios
                      abstractos, introduciendo los espacios métricos
                    </li>
                    <li>
                      <strong>Felix Hausdorff (1868-1942):</strong> Desarrolló la teoría de espacios topológicos,
                      permitiendo definir límites en contextos más generales
                    </li>
                    <li>
                      <strong>Stefan Banach (1892-1945):</strong> Su trabajo en análisis funcional extendió el concepto
                      de función a espacios de dimensión infinita
                    </li>
                    <li>
                      <strong>Laurent Schwartz (1915-2002):</strong> Desarrolló la teoría de distribuciones, que
                      generaliza el concepto de función para incluir "funciones" como la delta de Dirac
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Nuevas áreas y aplicaciones</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>Análisis numérico:</strong> Desarrollo de métodos computacionales para aproximar límites y
                      funciones
                    </li>
                    <li>
                      <strong>Análisis no estándar:</strong> Abraham Robinson (1918-1974) desarrolló un enfoque riguroso
                      para los infinitesimales, proporcionando una fundamentación alternativa para el cálculo
                    </li>
                    <li>
                      <strong>Teoría de la computabilidad:</strong> Alonzo Church (1903-1995) y Alan Turing (1912-1954)
                      formalizaron el concepto de función computable
                    </li>
                    <li>
                      <strong>Teoría de categorías:</strong> Proporciona un marco abstracto para estudiar funciones
                      (morfismos) entre objetos matemáticos
                    </li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Aplicaciones modernas</h3>
                  <ul className="list-disc pl-6">
                    <li>
                      <strong>Ecuaciones diferenciales:</strong> Modelan fenómenos físicos, biológicos, económicos y
                      sociales
                    </li>
                    <li>
                      <strong>Análisis de Fourier:</strong> Fundamental en procesamiento de señales, física cuántica y
                      muchas otras áreas
                    </li>
                    <li>
                      <strong>Análisis funcional:</strong> Base matemática para la mecánica cuántica y otras teorías
                      físicas
                    </li>
                    <li>
                      <strong>Ciencia de datos:</strong> Uso de funciones para modelar relaciones en grandes conjuntos
                      de datos
                    </li>
                    <li>
                      <strong>Inteligencia artificial:</strong> Las redes neuronales son esencialmente composiciones de
                      funciones no lineales
                    </li>
                  </ul>
                </div>
              </div>

              <p className="mt-4">
                La evolución de los conceptos de función y límite ilustra cómo las ideas matemáticas se desarrollan a lo
                largo del tiempo, desde intuiciones informales hasta teorías rigurosas, y cómo estas ideas se
                generalizan y encuentran aplicaciones en diversos campos.
              </p>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="impacto">
          <AccordionTrigger>Impacto en la Ciencia y Tecnología</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <p>
                Los conceptos de función y límite han tenido un impacto profundo en el desarrollo de la ciencia y la
                tecnología:
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Física</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6">
                      <li>
                        <strong>Mecánica clásica:</strong> Las leyes de Newton utilizan derivadas (basadas en límites)
                        para relacionar fuerza, masa y aceleración
                      </li>
                      <li>
                        <strong>Electromagnetismo:</strong> Las ecuaciones de Maxwell, que describen los fenómenos
                        electromagnéticos, son ecuaciones diferenciales
                      </li>
                      <li>
                        <strong>Relatividad:</strong> La teoría de Einstein utiliza cálculo tensorial, una
                        generalización del cálculo diferencial
                      </li>
                      <li>
                        <strong>Mecánica cuántica:</strong> Utiliza funciones de onda y operadores en espacios de
                        Hilbert
                      </li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Ingeniería</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6">
                      <li>
                        <strong>Control automático:</strong> Utiliza ecuaciones diferenciales para modelar y controlar
                        sistemas dinámicos
                      </li>
                      <li>
                        <strong>Procesamiento de señales:</strong> Basado en transformadas (Fourier, Laplace, wavelets)
                        que utilizan funciones y límites
                      </li>
                      <li>
                        <strong>Diseño estructural:</strong> Utiliza ecuaciones diferenciales para modelar tensiones y
                        deformaciones
                      </li>
                      <li>
                        <strong>Aerodinámica:</strong> Las ecuaciones de Navier-Stokes describen el flujo de fluidos
                      </li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Economía</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6">
                      <li>
                        <strong>Microeconomía:</strong> Utiliza derivadas para analizar la maximización de utilidad y
                        beneficio
                      </li>
                      <li>
                        <strong>Macroeconomía:</strong> Modela el crecimiento económico y los ciclos económicos con
                        ecuaciones diferenciales
                      </li>
                      <li>
                        <strong>Finanzas:</strong> La valoración de opciones utiliza ecuaciones diferenciales
                        estocásticas
                      </li>
                      <li>
                        <strong>Econometría:</strong> Utiliza funciones para modelar relaciones entre variables
                        económicas
                      </li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Computación</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-6">
                      <li>
                        <strong>Algoritmos:</strong> El análisis de complejidad utiliza funciones para describir el
                        rendimiento
                      </li>
                      <li>
                        <strong>Gráficos por computadora:</strong> Utiliza funciones para modelar superficies y
                        transformaciones
                      </li>
                      <li>
                        <strong>Inteligencia artificial:</strong> Las redes neuronales son composiciones de funciones no
                        lineales
                      </li>
                      <li>
                        <strong>Simulación:</strong> Utiliza métodos numéricos para aproximar soluciones de ecuaciones
                        diferenciales
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-4">
                <p className="font-semibold">Tecnologías modernas basadas en estos conceptos:</p>
                <ul className="list-disc pl-6">
                  <li>
                    <strong>GPS:</strong> Utiliza correcciones relativistas (basadas en cálculo) para proporcionar
                    ubicaciones precisas
                  </li>
                  <li>
                    <strong>Imágenes médicas:</strong> La tomografía computarizada utiliza transformadas matemáticas
                    para reconstruir imágenes
                  </li>
                  <li>
                    <strong>Compresión de datos:</strong> Formatos como JPEG y MP3 utilizan transformadas basadas en
                    funciones
                  </li>
                  <li>
                    <strong>Predicción meteorológica:</strong> Utiliza sistemas de ecuaciones diferenciales para modelar
                    la atmósfera
                  </li>
                  <li>
                    <strong>Aprendizaje profundo:</strong> Las redes neuronales profundas han revolucionado el
                    reconocimiento de imágenes, el procesamiento del lenguaje natural y muchas otras áreas
                  </li>
                </ul>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  )
}

function TestContent() {
  // Banco de preguntas completo
  const allQuestions = [
    {
      id: 1,
      question: (
        <div>
          ¿Cuál es el límite de <Fraction numerator={<>x² - 1</>} denominator={<>x - 1</>} /> cuando x tiende a 1?
        </div>
      ),
      options: [
        { id: "a", text: "0" },
        { id: "b", text: "1" },
        { id: "c", text: "2" },
        { id: "d", text: "No existe" },
      ],
      correctAnswer: "c",
      explanation: (
        <div>
          Esta es una indeterminación del tipo 0/0. Factorizando el numerador:{" "}
          <Fraction numerator={<>x² - 1</>} denominator={<>x - 1</>} /> ={" "}
          <Fraction numerator={<>(x - 1)(x + 1)</>} denominator={<>x - 1</>} /> = x + 1. Por lo tanto,{" "}
          <Limit variable="x" approach={1} expression={<Fraction numerator={<>x² - 1</>} denominator={<>x - 1</>} />} />{" "}
          = <Limit variable="x" approach={1} expression={"x + 1"} /> = 1 + 1 = 2.
        </div>
      ),
    },
    {
      id: 2,
      question: "¿Cuál de las siguientes funciones es continua en todo su dominio?",
      options: [
        {
          id: "a",
          text: (
            <div>
              f(x) = <Fraction numerator={1} denominator={"x"} />
            </div>
          ),
        },
        { id: "b", text: "f(x) = [x] (parte entera)" },
        {
          id: "c",
          text: (
            <div>
              f(x) = <Fraction numerator={"sin(x)"} denominator={"x"} />
            </div>
          ),
        },
        { id: "d", text: "f(x) = x²" },
      ],
      correctAnswer: "d",
      explanation: (
        <div>
          f(x) = 1/x no está definida en x = 0, por lo que tiene una discontinuidad. f(x) = [x] (parte entera de x)
          tiene discontinuidades en cada entero. f(x) = sin(x)/x no está definida en x = 0, aunque el límite existe.
          f(x) = x² es un polinomio, y todos los polinomios son continuos en todo ℝ.
        </div>
      ),
    },
    {
      id: 3,
      question: (
        <div>
          Si <Limit variable="x" approach={"∞"} expression={<Fraction numerator={"f(x)"} denominator={"x"} />} /> = 3 y{" "}
          <Limit variable="x" approach={"∞"} expression={"g(x)"} /> = 5, entonces{" "}
          <Limit variable="x" approach={"∞"} expression={<Fraction numerator={"f(x) + x·g(x)"} denominator={"x"} />} />{" "}
          es:
        </div>
      ),
      options: [
        { id: "a", text: "3" },
        { id: "b", text: "5" },
        { id: "c", text: "8" },
        { id: "d", text: "15" },
      ],
      correctAnswer: "c",
      explanation: (
        <div>
          <Limit variable="x" approach={"∞"} expression={<Fraction numerator={"f(x) + x·g(x)"} denominator={"x"} />} />{" "}
          = <Limit variable="x" approach={"∞"} expression={<>f(x)/x + g(x)</>} /> ={" "}
          <Limit variable="x" approach={"∞"} expression={"f(x)/x"} /> +{" "}
          <Limit variable="x" approach={"∞"} expression={"g(x)"} /> = 3 + 5 = 8.
        </div>
      ),
    },
    {
      id: 4,
      question: (
        <div>
          ¿Cuál es el dominio de la función f(x) = <Sqrt expression={"x² - 4"} />?
        </div>
      ),
      options: [
        { id: "a", text: "ℝ" },
        { id: "b", text: "x ≥ 0" },
        { id: "c", text: "x ≤ -2 o x ≥ 2" },
        { id: "d", text: "x ≥ 2" },
      ],
      correctAnswer: "c",
      explanation: (
        <div>
          Para que f(x) esté definida, necesitamos x² - 4 ≥ 0, lo que equivale a (x - 2)(x + 2) ≥ 0. Esto se cumple
          cuando x ≤ -2 o x ≥ 2. Por lo tanto, el dominio es (-∞, -2] ∪ [2, ∞).
        </div>
      ),
    },
    {
      id: 5,
      question: (
        <div>
          ¿Cuál es el valor de{" "}
          <Limit variable="x" approach={0} expression={<Fraction numerator={"1 - cos(x)"} denominator={"x²"} />} />?
        </div>
      ),
      options: [
        { id: "a", text: "0" },
        { id: "b", text: "1/2" },
        { id: "c", text: "1" },
        { id: "d", text: "∞" },
      ],
      correctAnswer: "b",
      explanation: (
        <div>
          Esta es una indeterminación del tipo 0/0. Podemos usar el desarrollo en serie de Taylor de cos(x) alrededor de
          x = 0: cos(x) = 1 - x²/2 + x⁴/24 - ... Por lo tanto, <Fraction numerator={"1 - cos(x)"} denominator={"x²"} />{" "}
          = <Fraction numerator={"x²/2 - x⁴/24 + ..."} denominator={"x²"} /> = 1/2 - x²/24 + ... Cuando x→0, obtenemos
          1/2.
        </div>
      ),
    },
    {
      id: 6,
      question: (
        <div>
          Si f(x) = x³ - 3x² + 2x - 1, ¿cuál es el valor de{" "}
          <Limit variable="h" approach={0} expression={<Fraction numerator={"f(2+h) - f(2)"} denominator={"h"} />} />?
        </div>
      ),
      options: [
        { id: "a", text: "1" },
        { id: "b", text: "2" },
        { id: "c", text: "3" },
        { id: "d", text: "4" },
      ],
      correctAnswer: "b",
      explanation: (
        <div>
          Este límite es la definición de la derivada de f en x = 2. Podemos calcular f'(x) = 3x² - 6x + 2, y luego
          evaluar f'(2) = 3(2)² - 6(2) + 2 = 12 - 12 + 2 = 2.
        </div>
      ),
    },
    {
      id: 7,
      question: "¿Cuál de las siguientes funciones tiene una asíntota horizontal?",
      options: [
        { id: "a", text: "f(x) = x³" },
        { id: "b", text: "f(x) = x² + 1" },
        {
          id: "c",
          text: (
            <div>
              f(x) = <Fraction numerator={"2x² + 1"} denominator={"x² + 1"} />
            </div>
          ),
        },
        { id: "d", text: "f(x) = e^x" },
      ],
      correctAnswer: "c",
      explanation: (
        <div>
          Para determinar si una función tiene una asíntota horizontal, calculamos{" "}
          <Limit variable="x" approach={"±∞"} expression={"f(x)"} />. Para f(x) ={" "}
          <Fraction numerator={"2x² + 1"} denominator={"x² + 1"} />, dividiendo numerador y denominador por x²,
          obtenemos{" "}
          <Limit
            variable="x"
            approach={"∞"}
            expression={<Fraction numerator={"2 + 1/x²"} denominator={"1 + 1/x²"} />}
          />{" "}
          = 2. Por lo tanto, y = 2 es una asíntota horizontal.
        </div>
      ),
    },
    {
      id: 8,
      question: (
        <div>
          ¿Cuál es el valor de <Limit variable="x" approach={"∞"} expression={<>x · sin(1/x)</>} />?
        </div>
      ),
      options: [
        { id: "a", text: "0" },
        { id: "b", text: "1" },
        { id: "c", text: "No existe" },
        { id: "d", text: "∞" },
      ],
      correctAnswer: "b",
      explanation: (
        <div>
          Haciendo el cambio de variable u = 1/x, tenemos que cuando x → ∞, u → 0. Entonces,{" "}
          <Limit variable="x" approach={"∞"} expression={<>x · sin(1/x)</>} /> ={" "}
          <Limit variable="u" approach={0} expression={<Fraction numerator={"sin(u)"} denominator={"u"} />} /> = 1, ya
          que sabemos que{" "}
          <Limit variable="u" approach={0} expression={<Fraction numerator={"sin(u)"} denominator={"u"} />} /> = 1.
        </div>
      ),
    },
    {
      id: 9,
      question: (
        <div>
          ¿Cuál es el valor de{" "}
          <Limit variable="x" approach={0} expression={<Fraction numerator={"tan(3x)"} denominator={"sin(5x)"} />} />?
        </div>
      ),
      options: [
        { id: "a", text: <Fraction numerator={3} denominator={5} /> },
        { id: "b", text: <Fraction numerator={5} denominator={3} /> },
        { id: "c", text: "1" },
        { id: "d", text: "0" },
      ],
      correctAnswer: "a",
      explanation: (
        <div>
          Esta es una indeterminación del tipo 0/0. Usamos los límites fundamentales:{" "}
          <Limit variable="x" approach={0} expression={<Fraction numerator={"sin(x)"} denominator={"x"} />} /> = 1 y{" "}
          <Limit variable="x" approach={0} expression={<Fraction numerator={"tan(x)"} denominator={"x"} />} /> = 1.
          Entonces,{" "}
          <Limit variable="x" approach={0} expression={<Fraction numerator={"tan(3x)"} denominator={"sin(5x)"} />} /> ={" "}
          <Limit
            variable="x"
            approach={0}
            expression={<Fraction numerator={"3x · (tan(3x)/3x)"} denominator={"5x · (sin(5x)/5x)"} />}
          />{" "}
          = <Fraction numerator={3} denominator={5} /> ·{" "}
          <Limit
            variable="x"
            approach={0}
            expression={<Fraction numerator={"tan(3x)/3x"} denominator={"sin(5x)/5x"} />}
          />{" "}
          = <Fraction numerator={3} denominator={5} /> · <Fraction numerator={1} denominator={1} /> ={" "}
          <Fraction numerator={3} denominator={5} />.
        </div>
      ),
    },
    {
      id: 10,
      question: (
        <div>
          ¿Cuál es el valor de{" "}
          <Limit
            variable="x"
            approach={"∞"}
            expression={
              <>
                (1 + <Fraction numerator={2} denominator={"x"} />)<sup>x</sup>
              </>
            }
          />
          ?
        </div>
      ),
      options: [
        { id: "a", text: "1" },
        { id: "b", text: "e" },
        { id: "c", text: "e²" },
        { id: "d", text: "∞" },
      ],
      correctAnswer: "c",
      explanation: (
        <div>
          Usando la propiedad{" "}
          <Limit
            variable="x"
            approach={"∞"}
            expression={
              <>
                (1 + <Fraction numerator={"a"} denominator={"x"} />)<sup>x</sup>
              </>
            }
          />{" "}
          = e^a, con a = 2, obtenemos{" "}
          <Limit
            variable="x"
            approach={"∞"}
            expression={
              <>
                (1 + <Fraction numerator={2} denominator={"x"} />)<sup>x</sup>
              </>
            }
          />{" "}
          = e².
        </div>
      ),
    },
    {
      id: 11,
      question: (
        <div>
          Si f(x) = <Fraction numerator={"x² - 4"} denominator={"x - 2"} />, ¿cuál es el valor de{" "}
          <Limit variable="x" approach={2} expression={"f(x)"} />?
        </div>
      ),
      options: [
        { id: "a", text: "0" },
        { id: "b", text: "4" },
        { id: "c", text: "No existe" },
        { id: "d", text: "∞" },
      ],
      correctAnswer: "b",
      explanation: (
        <div>
          Esta es una indeterminación del tipo 0/0. Factorizando el numerador:{" "}
          <Fraction numerator={"x² - 4"} denominator={"x - 2"} /> ={" "}
          <Fraction numerator={"(x - 2)(x + 2)"} denominator={"x - 2"} /> = x + 2 para x ≠ 2. Por lo tanto,{" "}
          <Limit variable="x" approach={2} expression={"f(x)"} /> ={" "}
          <Limit variable="x" approach={2} expression={"x + 2"} /> = 2 + 2 = 4.
        </div>
      ),
    },
    {
      id: 12,
      question: (
        <div>
          ¿Cuál es el valor de{" "}
          <Limit variable="x" approach={0} expression={<Fraction numerator={"e^x - 1"} denominator={"x"} />} />?
        </div>
      ),
      options: [
        { id: "a", text: "0" },
        { id: "b", text: "1" },
        { id: "c", text: "e" },
        { id: "d", text: "∞" },
      ],
      correctAnswer: "b",
      explanation: (
        <div>
          Esta es una indeterminación del tipo 0/0. Usando el desarrollo en serie de Taylor de e^x alrededor de x = 0:
          e^x = 1 + x + x²/2! + ... Por lo tanto, <Fraction numerator={"e^x - 1"} denominator={"x"} /> ={" "}
          <Fraction numerator={"1 + x + x²/2! + ... - 1"} denominator={"x"} /> ={" "}
          <Fraction numerator={"x + x²/2! + ..."} denominator={"x"} /> = 1 + x/2! + ... Cuando x→0, obtenemos 1.
        </div>
      ),
    },
    {
      id: 13,
      question: (
        <div>
          ¿Cuál es el valor de{" "}
          <Limit variable="x" approach={"π/2"} expression={<Fraction numerator={"tan(x)"} denominator={"cos(x)"} />} />?
        </div>
      ),
      options: [
        { id: "a", text: "0" },
        { id: "b", text: "1" },
        { id: "c", text: "-1" },
        { id: "d", text: "∞" },
      ],
      correctAnswer: "d",
      explanation: (
        <div>
          Sabemos que tan(x) = <Fraction numerator={"sin(x)"} denominator={"cos(x)"} />. Por lo tanto,{" "}
          <Fraction numerator={"tan(x)"} denominator={"cos(x)"} /> ={" "}
          <Fraction numerator={"sin(x)"} denominator={"cos(x)²"} />. Cuando x → π/2, cos(x) → 0 y sin(x) → 1. Por lo
          tanto,{" "}
          <Limit variable="x" approach={"π/2"} expression={<Fraction numerator={"sin(x)"} denominator={"cos(x)²"} />} />{" "}
          = <Fraction numerator={1} denominator={0} /> = ∞.
        </div>
      ),
    },
    {
      id: 14,
      question: (
        <div>
          ¿Cuál es el valor de{" "}
          <Limit variable="x" approach={0} expression={<Fraction numerator={"ln(1 + x)"} denominator={"x"} />} />?
        </div>
      ),
      options: [
        { id: "a", text: "0" },
        { id: "b", text: "1" },
        { id: "c", text: "e" },
        { id: "d", text: "∞" },
      ],
      correctAnswer: "b",
      explanation: (
        <div>
          Esta es una indeterminación del tipo 0/0. Usando el desarrollo en serie de Taylor de ln(1 + x) alrededor de x
          = 0: ln(1 + x) = x - x²/2 + x³/3 - ... Por lo tanto, <Fraction numerator={"ln(1 + x)"} denominator={"x"} /> ={" "}
          <Fraction numerator={"x - x²/2 + x³/3 - ..."} denominator={"x"} /> = 1 - x/2 + x²/3 - ... Cuando x→0,
          obtenemos 1.
        </div>
      ),
    },
  ]

  const [selectedAnswers, setSelectedAnswers] = useState({})
  const [showResults, setShowResults] = useState(false)
  const [score, setScore] = useState(null)
  const [currentQuestions, setCurrentQuestions] = useState([])
  const [questionsLoaded, setQuestionsLoaded] = useState(false)

  // Función para seleccionar preguntas aleatorias
  const selectRandomQuestions = () => {
    const shuffled = [...allQuestions].sort(() => 0.5 - Math.random())
    return shuffled.slice(0, 7) // Selecciona 7 preguntas aleatorias
  }

  // Inicializar preguntas aleatorias al cargar el componente
  useEffect(() => {
    if (!questionsLoaded) {
      const randomQuestions = selectRandomQuestions()
      setCurrentQuestions(randomQuestions)
      setQuestionsLoaded(true)
    }
  }, [questionsLoaded])

  const handleAnswerSelect = (questionId, answerId) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: answerId,
    }))
  }

  const calculateScore = () => {
    let correct = 0
    currentQuestions.forEach((question) => {
      if (selectedAnswers[question.id] === question.correctAnswer) {
        correct++
      }
    })
    setScore(correct)
    setShowResults(true)
  }

  const resetTest = () => {
    setSelectedAnswers({})
    setShowResults(false)
    setScore(null)
    // Generar nuevas preguntas aleatorias
    const randomQuestions = selectRandomQuestions()
    setCurrentQuestions(randomQuestions)
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Test de Conocimientos: Límites y Funciones</h2>
        <Button onClick={resetTest} className="flex items-center gap-2" variant="outline">
          <RefreshCw className="h-4 w-4" />
          Nuevas Preguntas
        </Button>
      </div>

      <p className="text-lg">
        Responde las siguientes preguntas para evaluar tu comprensión de los conceptos de límites y funciones.
      </p>

      <div className="space-y-10">
        {currentQuestions.map((question, index) => (
          <div key={question.id} className="border rounded-lg p-6 bg-white shadow-sm">
            <h3 className="text-xl font-semibold mb-4">
              {index + 1}. {question.question}
            </h3>

            <RadioGroup
              value={selectedAnswers[question.id]}
              onValueChange={(value) => handleAnswerSelect(question.id, value)}
              className="space-y-3"
              disabled={showResults}
            >
              {question.options.map((option) => (
                <div key={option.id} className="flex items-center space-x-2">
                  <RadioGroupItem value={option.id} id={`q${question.id}-${option.id}`} />
                  <Label htmlFor={`q${question.id}-${option.id}`} className="text-base">
                    {option.id}) {option.text}
                  </Label>
                </div>
              ))}
            </RadioGroup>

            {showResults && (
              <div
                className={`mt-4 p-4 ${selectedAnswers[question.id] === question.correctAnswer ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"} border rounded-md`}
              >
                <div className="flex items-start">
                  {selectedAnswers[question.id] === question.correctAnswer ? (
                    <>
                      <div className="h-5 w-5 text-green-500 mr-2 mt-0.5">✓</div>
                      <div>
                        <p className="font-semibold text-green-700">¡Respuesta correcta!</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="h-5 w-5 text-red-500 mr-2 mt-0.5" />
                      <div>
                        <p className="font-semibold text-red-700">Respuesta incorrecta</p>
                        <p className="mt-1">
                          La respuesta correcta es: {question.options.find((o) => o.id === question.correctAnswer).text}
                        </p>
                      </div>
                    </>
                  )}
                </div>
                <div className="mt-2 pl-7">
                  <p className="font-medium">Explicación:</p>
                  <div className="mt-1">{question.explanation}</div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-8 gap-4">
        {!showResults ? (
          <Button
            onClick={calculateScore}
            className="px-8 py-2"
            disabled={Object.keys(selectedAnswers).length < currentQuestions.length}
          >
            Verificar Resultados
          </Button>
        ) : (
          <Button onClick={resetTest} className="px-8 py-2">
            Reiniciar Test con Nuevas Preguntas
          </Button>
        )}
      </div>

      {showResults && (
        <div className="mt-6 p-6 bg-blue-50 border border-blue-200 rounded-md text-center">
          <h3 className="text-xl font-bold mb-2">Resultado Final</h3>
          <p className="text-lg">
            Has respondido correctamente {score} de {currentQuestions.length} preguntas.
          </p>
          <p className="mt-2">
            {score === currentQuestions.length
              ? "¡Excelente! Has dominado los conceptos de límites y funciones."
              : "Revisa las explicaciones de las respuestas incorrectas para mejorar tu comprensión."}
          </p>
        </div>
      )}
    </div>
  )
}


// test.js - Manejo del sistema de test

// Banco de preguntas por dificultad
const questions = {
    facil: [
      {
        question: "¿Cuál es el valor de f(x) = 2x + 3 cuando x = 4?",
        options: ["5", "8", "11", "14"],
        answer: 2,
        explanation: "Sustituyendo x = 4 en la función: f(4) = 2(4) + 3 = 8 + 3 = 11"
      },
      {
        question: "¿Cuál es el límite de f(x) = 5 cuando x tiende a 2?",
        options: ["0", "2", "5", "No existe"],
        answer: 2,
        explanation: "El límite de una constante es siempre la misma constante, independientemente del valor al que tienda x."
      },
      {
        question: "¿Cuál es el dominio de la función f(x) = x + 2?",
        options: ["Números naturales", "Números enteros", "Números reales", "Números positivos"],
        answer: 2,
        explanation: "La función f(x) = x + 2 está definida para todos los números reales, por lo que su dominio es ℝ."
      },
      {
        question: "¿Cuál es el valor de f(x) = x² cuando x = -3?",
        options: ["3", "-9", "9", "-3"],
        answer: 2,
        explanation: "Al elevar -3 al cuadrado: (-3)² = 9"
      },
      {
        question: "¿Cuál es el límite de f(x) = 3x + 1 cuando x tiende a 0?",
        options: ["0", "1", "3", "4"],
        answer: 1,
        explanation: "Sustituyendo x = 0 en la función: f(0) = 3(0) + 1 = 1"
      },
      {
        question: "¿Cuál es el rango de la función f(x) = 2?",
        options: ["Todos los números reales", "{2}", "Los números mayores que 2", "Los números menores que 2"],
        answer: 1,
        explanation: "Una función constante siempre da el mismo valor, en este caso 2, por lo que su rango es el conjunto {2}."
      },
      {
        question: "¿Cuál es la pendiente de la función f(x) = 3x - 4?",
        options: ["4", "-4", "3", "-3"],
        answer: 2,
        explanation: "En una función lineal f(x) = mx + b, m es la pendiente. En este caso, m = 3."
      },
      {
        question: "Si f(x) = x + 5 y g(x) = 2x, ¿cuál es el valor de (f + g)(2)?",
        options: ["7", "9", "11", "13"],
        answer: 2,
        explanation: "(f + g)(2) = f(2) + g(2) = (2 + 5) + (2·2) = 7 + 4 = 11"
      },
      {
        question: "¿Cuál es el valor de f(0) si f(x) = |x|?",
        options: ["1", "-1", "No existe", "0"],
        answer: 3,
        explanation: "El valor absoluto de 0 es 0."
      },
      {
        question: "¿Cuál es el límite de f(x) = 4x cuando x tiende a 1?",
        options: ["1", "2", "3", "4"],
        answer: 3,
        explanation: "Sustituyendo x = 1 en la función: f(1) = 4(1) = 4"
      }
    ],
    medio: [
      {
        question: "¿Cuál es el límite de (x² - 4)/(x - 2) cuando x tiende a 2?",
        options: ["0", "2", "4", "No existe"],
        answer: 2,
        explanation: "Factorizando: (x-2)(x+2)/(x-2) = x+2. Evaluando en x=2: 2+2=4"
      },
      {
        question: "¿Cuál es la derivada de f(x) = 3x² + 2x - 1?",
        options: ["6x + 2", "3x + 2", "6x", "6x² + 2"],
        answer: 0,
        explanation: "La derivada de 3x² es 6x, de 2x es 2, y de -1 es 0. Sumando: 6x + 2"
      },
      {
        question: "¿Cuál es el límite de (x³ - 8)/(x - 2) cuando x tiende a 2?",
        options: ["8", "12", "16", "No existe"],
        answer: 1,
        explanation: "Factorizando: (x - 2)(x² + 2x + 4)/(x - 2) = x² + 2x + 4. Evaluando en x=2: 4 + 4 + 4 = 12"
      },
      {
        question: "¿Cuál es la derivada de f(x) = x⁴ - 2x² + 3x?",
        options: ["4x³ - 4x + 3", "4x³ - 2x + 3", "4x³ - 2x² + 3", "x³ - 2x + 3"],
        answer: 0,
        explanation: "La derivada de x⁴ es 4x³, de -2x² es -4x, y de 3x es 3. Sumando: 4x³ - 4x + 3"
      },
      {
        question: "¿Cuál es el límite de sin(x)/x cuando x tiende a 0?",
        options: ["0", "1", "∞", "No existe"],
        answer: 1,
        explanation: "Este es un límite fundamental del cálculo, su valor es 1."
      },
      {
        question: "Si f(x) = x² + 2x y g(x) = x - 1, ¿cuál es (f ∘ g)(2)?",
        options: ["7", "9", "11", "13"],
        answer: 1,
        explanation: "(f ∘ g)(2) = f(g(2)) = f(1) = 1² + 2(1) = 1 + 2 = 3"
      },
      {
        question: "¿Cuál es la derivada de f(x) = sin(x)cos(x)?",
        options: ["cos²(x) - sin²(x)", "2cos(x)", "cos(2x)", "-sin(2x)"],
        answer: 2,
        explanation: "Usando la regla del producto y la identidad trigonométrica, la derivada es cos(2x)."
      },
      {
        question: "¿Cuál es el límite de (1 - cos(x))/x cuando x tiende a 0?",
        options: ["0", "1/2", "1", "No existe"],
        answer: 0,
        explanation: "Usando L'Hôpital o desarrollo de Taylor, se obtiene que el límite es 0."
      },
      {
        question: "¿Cuál es la derivada de f(x) = e^x · ln(x)?",
        options: ["e^x(ln(x) + 1)", "e^x · 1/x", "e^x(1/x + ln(x))", "e^x/x"],
        answer: 2,
        explanation: "Usando la regla del producto: f'(x) = e^x·ln(x) + e^x·(1/x) = e^x(ln(x) + 1/x)"
      },
      {
        question: "¿Cuál es el límite de (x² - 1)/(x - 1) cuando x tiende a 1?",
        options: ["0", "1", "2", "No existe"],
        answer: 2,
        explanation: "Factorizando: (x + 1)(x - 1)/(x - 1) = x + 1. Evaluando en x=1: 1 + 1 = 2"
      }
    ],
    dificil: [
      {
        question: "¿Cuál es el límite de (1 - cos(x))/x² cuando x tiende a 0?",
        options: ["0", "1/2", "1", "2"],
        answer: 1,
        explanation: "Usando desarrollo de Taylor o L'Hôpital, se obtiene 1/2 como resultado."
      },
      {
        question: "¿Cuál es la derivada de f(x) = e^(2x) · sin(x)?",
        options: [
          "e^(2x)(2sin(x) + cos(x))",
          "2e^(2x)sin(x) + e^(2x)cos(x)",
          "e^(2x)(sin(x) + cos(x))",
          "2e^(2x)cos(x)"
        ],
        answer: 0,
        explanation: "Aplicando la regla del producto: f'(x) = 2e^(2x)sin(x) + e^(2x)cos(x) = e^(2x)(2sin(x) + cos(x))"
      },
      {
        question: "¿Cuál es el límite de (sin(x) - x)/x³ cuando x tiende a 0?",
        options: ["-1/6", "0", "1/6", "No existe"],
        answer: 2,
        explanation: "Usando el desarrollo de Taylor de sin(x) hasta el tercer término, se obtiene 1/6."
      },
      {
        question: "¿Cuál es la derivada de f(x) = arctan(x)/ln(1 + x²)?",
        options: [
          "(1/(1+x²))·ln(1+x²) - 2x·arctan(x)/(1+x²)ln²(1+x²)",
          "(1 - 2x·arctan(x))/(1+x²)ln(1+x²)",
          "(1 + 2x·arctan(x))/(1+x²)ln²(1+x²)",
          "1/(1+x²)ln(1+x²)"
        ],
        answer: 0,
        explanation: "Aplicando la regla del cociente y la cadena."
      },
      {
        question: "¿Cuál es el límite de (e^x - 1 - x)/x² cuando x tiende a 0?",
        options: ["0", "1/2", "1", "No existe"],
        answer: 1,
        explanation: "Usando el desarrollo de Taylor de e^x hasta el segundo término."
      },
      {
        question: "¿Cuál es la derivada de f(x) = x^x?",
        options: [
          "x^x(1 + ln(x))",
          "x^x·ln(x)",
          "x^(x-1)(x + ln(x))",
          "x^x(ln(x) + 1/x)"
        ],
        answer: 0,
        explanation: "Usando logaritmos y la regla de la cadena: f'(x) = x^x(1 + ln(x))"
      },
      {
        question: "¿Cuál es el límite de (ln(1+x) - x)/x² cuando x tiende a 0?",
        options: ["-1/2", "0", "1/2", "No existe"],
        answer: 0,
        explanation: "Usando el desarrollo de Taylor de ln(1+x) hasta el segundo término."
      },
      {
        question: "¿Cuál es la derivada de f(x) = (sin(x))^(cos(x))?",
        options: [
          "f(x)[cos(x)/sin(x) - ln(sin(x))sin(x)]",
          "f(x)[cot(x) - ln(sin(x))sin(x)]",
          "f(x)[ln(sin(x))cos(x) + cot(x)]",
          "f(x)[-ln(sin(x))sin(x)]"
        ],
        answer: 1,
        explanation: "Usando logaritmos y las reglas de la cadena y del producto."
      },
      {
        question: "¿Cuál es el límite de (tan(x) - sin(x))/x³ cuando x tiende a 0?",
        options: ["0", "1/2", "1/3", "1/6"],
        answer: 1,
        explanation: "Usando el desarrollo de Taylor de tan(x) y sin(x)."
      },
      {
        question: "¿Cuál es la derivada de f(x) = W(x), donde W es la función de Lambert?",
        options: [
          "W(x)/(x(1+W(x)))",
          "W(x)/x",
          "1/(1+W(x))",
          "W(x)/(1+W(x))"
        ],
        answer: 0,
        explanation: "La derivada de la función de Lambert W(x) es W(x)/(x(1+W(x)))."
      }
    ]
  };
  
  // Variables globales
  let currentQuestion = 0;
  let score = 0;
  let selectedDifficulty = '';
  let currentQuestions = [];
  
  // Función para iniciar el test
  function startTest(difficulty) {
    selectedDifficulty = difficulty;
    currentQuestion = 0;
    score = 0;
    
    // Ocultar selector de dificultad y mostrar el test
    document.getElementById('difficulty-selection').classList.add('hidden');
    document.getElementById('quiz-container').classList.remove('hidden');
    document.getElementById('result-container').classList.add('hidden');
    
    // Cargar preguntas según la dificultad
    currentQuestions = questions[difficulty];
    
    // Mostrar primera pregunta
    showQuestion();
    
    // Actualizar contadores
    updateProgress();
  }
  
  // Función para mostrar la pregunta actual
  function showQuestion() {
    const question = currentQuestions[currentQuestion];
    document.getElementById('question').textContent = question.question;
    
    // Generar opciones
    const optionsContainer = document.getElementById('options');
    optionsContainer.innerHTML = '';
    
    question.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.className = 'w-full text-left p-4 mb-2 border border-gray-200 rounded-lg hover:bg-blue-50 transition-colors cursor-pointer';
        button.textContent = option;
        button.addEventListener('click', () => selectOption(index));
        optionsContainer.appendChild(button);
    });
    
    // Deshabilitar el botón siguiente hasta que se seleccione una opción
    document.getElementById('next-btn').disabled = true;
    
    // Ocultar el feedback anterior si existe
    const feedback = document.getElementById('feedback');
    feedback.classList.add('hidden');
  }
  
  // Función para seleccionar una opción
  function selectOption(optionIndex) {
    // Remover la selección anterior
    const options = document.querySelectorAll('#options button');
    options.forEach(option => {
        option.classList.remove('bg-blue-100', 'border-blue-500', 'bg-green-100', 'border-green-500', 'bg-red-100', 'border-red-500');
        option.classList.add('border-gray-200');
    });
    
    // Marcar la opción seleccionada
    options[optionIndex].classList.remove('border-gray-200');
    
    // Verificar si la respuesta es correcta
    const question = currentQuestions[currentQuestion];
    if (optionIndex === question.answer) {
        // Respuesta correcta
        options[optionIndex].classList.add('bg-green-100', 'border-green-500');
        score++;
        updateProgress();
        
        // Deshabilitar todas las opciones
        options.forEach(option => option.disabled = true);
        
        // Habilitar el botón siguiente
        document.getElementById('next-btn').disabled = false;
    } else {
        // Respuesta incorrecta
        options[optionIndex].classList.add('bg-red-100', 'border-red-500');
        options[question.answer].classList.add('bg-green-100', 'border-green-500');
        
        // Mostrar feedback
        const feedback = document.getElementById('feedback');
        feedback.textContent = `Incorrecto. La respuesta correcta era: ${question.options[question.answer]}. Explicación: ${question.explanation}`;
        feedback.className = 'bg-red-100 border border-red-400 text-red-700 p-4 rounded-lg mb-6';
        feedback.classList.remove('hidden');
        
        // Deshabilitar todas las opciones
        options.forEach(option => option.disabled = true);
        
        // Habilitar el botón siguiente
        document.getElementById('next-btn').disabled = false;
    }
  }
  
  // Función para pasar a la siguiente pregunta
  function nextQuestion() {
    // Actualizar contadores
    currentQuestion++;
    updateProgress();
    
    // Verificar si es la última pregunta
    if (currentQuestion >= currentQuestions.length) {
        showResults();
    } else {
        showQuestion();
    }
  }
  
  // Función para salir del test
  function exitTest() {
    // Volver a mostrar el selector de dificultad
    document.getElementById('difficulty-selection').classList.remove('hidden');
    document.getElementById('quiz-container').classList.add('hidden');
    document.getElementById('result-container').classList.add('hidden');
    
    // Resetear variables
    currentQuestion = 0;
    score = 0;
    selectedDifficulty = '';
    currentQuestions = [];
  }
  
  // Función para reiniciar el test
  function restartTest() {
    startTest(selectedDifficulty);
  }
  
  // Función para actualizar la barra de progreso
  function updateProgress() {
    const progress = ((currentQuestion + 1) / currentQuestions.length) * 100;
    document.getElementById('progress-bar').style.width = `${progress}%`;
    document.getElementById('question-number').textContent = `Pregunta ${currentQuestion + 1} de ${currentQuestions.length}`;
    document.getElementById('score-counter').textContent = `Correctas: ${score}`;
  }
  
  // Función para mostrar resultados
  function showResults() {
    document.getElementById('quiz-container').classList.add('hidden');
    document.getElementById('result-container').classList.remove('hidden');
    
    const percentage = (score / currentQuestions.length) * 100;
    document.getElementById('result-percentage').textContent = `${percentage}%`;
    
    let resultText = '';
    if (percentage >= 80) {
        resultText = '¡Excelente! Has dominado el tema.';
    } else if (percentage >= 60) {
        resultText = '¡Buen trabajo! Pero hay espacio para mejorar.';
    } else {
        resultText = 'Necesitas practicar más. ¡No te rindas!';
    }
    document.getElementById('result-text').textContent = resultText;
    
    // Mostrar el número total de respuestas correctas
    document.getElementById('correct-answers').textContent = `${score} de ${currentQuestions.length}`;
  }
  
  // Event Listeners
  document.addEventListener('DOMContentLoaded', () => {
    // Agregar event listener al botón siguiente
    document.getElementById('next-btn').addEventListener('click', nextQuestion);
    
    // Agregar event listener al botón salir
    document.getElementById('exit-btn').addEventListener('click', exitTest);
    
    // Configurar el año actual en el footer
    document.getElementById('current-year').textContent = new Date().getFullYear();
  });
// script.js - Manejo de la pantalla de bienvenida y pestañas

document.addEventListener('DOMContentLoaded', function() {
  // Actualizar el año en el footer
  document.getElementById('current-year').textContent = new Date().getFullYear();
  
  // Elementos del DOM
  const welcomeScreen = document.getElementById('welcome-screen');
  const startButton = document.getElementById('start-button');
  const mainContent = document.getElementById('main-content');
  
  // Manejar clic en el botón de inicio
  startButton.addEventListener('click', function() {
    // Ocultar pantalla de bienvenida con animación
    welcomeScreen.style.opacity = '0';
    
    // Mostrar contenido principal después de la animación
    setTimeout(function() {
      welcomeScreen.classList.add('hidden');
      mainContent.classList.remove('hidden');
      
      // Inicializar las pestañas
      setupTabs();
      // Inicializar el acordeón
      setupAccordion();
    }, 500); // Tiempo igual a la duración de la transición CSS
  });
  
  // Configurar pestañas
  function setupTabs() {
    const tabTriggers = document.querySelectorAll('.tab-trigger');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabTriggers.forEach(trigger => {
      trigger.addEventListener('click', function() {
        // Remover clase active de todos los triggers
        tabTriggers.forEach(t => t.classList.remove('active'));
        
        // Añadir clase active al trigger clickeado
        this.classList.add('active');
        
        // Ocultar todos los contenidos
        tabContents.forEach(content => content.classList.add('hidden'));
        
        // Mostrar el contenido correspondiente
        const tabId = this.getAttribute('data-tab');
        document.getElementById(`${tabId}-content`).classList.remove('hidden');
      });
    });
    
    // Activar la primera pestaña por defecto
    tabTriggers[0].click();
  }

  // Configurar acordeón
  function setupAccordion() {
    const accordionTriggers = document.querySelectorAll('.accordion-trigger');
    
    accordionTriggers.forEach(trigger => {
      trigger.addEventListener('click', function() {
        // Toggle clase active en el trigger
        this.classList.toggle('active');
        
        // Obtener el contenido asociado
        const content = this.nextElementSibling;
        
        // Toggle la visibilidad del contenido
        content.classList.toggle('hidden');
        
        // Rotar el icono
        const icon = this.querySelector('.accordion-icon');
        if (icon) {
          icon.style.transform = content.classList.contains('hidden') ? 'rotate(0)' : 'rotate(180deg)';
        }
      });
    });
  }

  // Inicializar el acordeón inmediatamente si no estamos en la pantalla de bienvenida
  if (!welcomeScreen || welcomeScreen.classList.contains('hidden')) {
    setupAccordion();
  }
});